#include <iostream>
using namespace std;
#include <time.h> //used for randomization
#include <string> //used so I can use string datatype
#include <Windows.h> //used for changing color of graphics
#include <fstream> //used for reading in file
#include <thread>
int sleepStatus = 4;
int foodStatus = 3;
int happyStatus = 0;
int main() {

    //DEFINE VARIABLES 

    srand(time(NULL)); //generate a random number through use of time library
    void gravestone(); // simple graphic printing function
    void foodMessage(int);
    void sleepMessage(int);
    void timer();
    void happyCalc(int);
    char playerChoice{};
    char nameChoice{};
    int happiness = 0;
    int currentVal = 0;
    void getInstructions(string);
    string petName;


    //Get current console's color data so we can reset to it, because the CONSOLE_SCREEN_BUFFER_INFO can give us wAttributes, which is the current console's settings we can plug into setconsoletextattribute from Windows.h - honestly a bit of a nightmare. 
    HANDLE inputHandle; //define this as a handle(which can really be anything, it's an abstract resource) so we can assign GetStdHandle later.
    WORD baseConAttributes; // because we're using windows functions use WORD which is a windows data type.
    CONSOLE_SCREEN_BUFFER_INFO ScreenInfo; //define ScreenInfo as equal to the info from the console screen, needed so it can be pointed to by GetConsoleScreenBufferInfo
    inputHandle = GetStdHandle(STD_OUTPUT_HANDLE); //GetStdHandle for STD_OUTPUT_HANDLE, STD_OUTPUT_HANDLE being our console. Assign a variable so we can use it in Getscreenbufferinfo and later in setconsoletextattribute, as opposed to directly entering it as we do with colour usage. 
    GetConsoleScreenBufferInfo(inputHandle, &ScreenInfo); //using our previous variables get the info of the current console. 
    baseConAttributes = ScreenInfo.wAttributes; //we only want the wAttribute bit of the Buffer Info, because we can feed it straight into SetConsoleTextAttribute

    while (nameChoice != 'Y' && nameChoice != 'N') { //don't allow user to proceed until a valid choice is made

        cout << "Would you like to name your pet? Y/N ";
        cin >> nameChoice;
        cin.ignore(); //necessary for getline function to ignore first example of cin, which is a character, and use our second cin which is the name entry. 
        if (nameChoice == 'Y') {
            cout << "Enter name:";
            getline(cin, petName); // without getline a name that was entered with a space would break the program, getline means that you can have as complicated a name as you like.
        }
        else if (nameChoice == 'N') {
            petName = "your pet";
        }
    }


    //GRAPHICS USING ASCII ART
    string myArr[10]; //create array
    ifstream file("Animals.txt"); //read in animals.txt, because otherwise our cpp file is going to be very messy - more reasonable to have a seperate file. 
    for (int i = 0; i < 10; ++i)
    {
        getline(file, myArr[i], '@'); //read in each value as a string, append them to an array and use @ as the delimiter (would usually use comma, but ASCII art necessesitates an easier character due to ,'s frequent usage)
    }
    int RandIndex = rand() % 10; //pick one of the animals in the array at random
    cout << myArr[RandIndex]; //output random animal
    cout << endl;
    cout << "This is " << petName << endl;
    while (playerChoice != 'Q' && foodStatus != 0) { //only continue whilst pet is alive or exit button has not been pressed
        getInstructions(petName);
        if (playerChoice == 'F' || playerChoice == 'N' || playerChoice == 'P' ) {
            int RandomNum = rand() % 2;
            int RandomNum1 = rand() % 2; //randomly decide a decrease in value
            if (RandomNum == 0) { //pick between the two variables to decrease
                foodStatus = foodStatus - RandomNum1; //randomly decide a decrease in value

            }
            else {
                sleepStatus = sleepStatus - RandomNum1; //randomly decide a decrease in value
            }
        }
        while (foodStatus == 1) { // only do this if pet is one step away from death. 

            fflush(stdout); //flush the output buffer to ensure all the text before remains grey
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | FOREGROUND_INTENSITY); //set text to bright red because it's an important message
            cout << "WARNING - PLEASE FEED YOUR PET, THEY ARE VERY HUNGRY" << endl;
            SetConsoleTextAttribute(inputHandle, baseConAttributes); //reset text to base colours 
            break;
        }
        while (sleepStatus == 1) {
            fflush(stdout); //flush the output buffer to ensure all the text before remains grey
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_BLUE | FOREGROUND_INTENSITY); //set text to bright red because it's an important message
            cout << "Your Pet has Collapsed, please wait 30 seconds for them to recover" << endl;
            for (int i = 30; i > -1; --i) {
                printf("Time: %d \r", i);
                fflush(stdout);
                std::this_thread::sleep_for(std::chrono::seconds(1));
            }
            sleepStatus = 3;
            SetConsoleTextAttribute(inputHandle, baseConAttributes); //reset text to base colours
            continue;
        }
        while (sleepStatus == 0) {
            sleepStatus = 1;
        }


        cin >> playerChoice;
        happiness = sleepStatus + foodStatus + happyStatus; //used to calculate happiness and modify it by playing with our pet.
        switch (playerChoice) { //using switch as we only have need to check 1 char object per choice, also generally looks better.  
            case 'F':
                foodStatus++;
                while (foodStatus > 4) {
                    foodStatus--; //ensure cannot be greater than 'well fed' aka value 4 in foodMessage
                }
                cout << "New Food Status:";
                foodMessage(foodStatus);
                break;


            case 'N':
                sleepStatus++;
                while (sleepStatus > 5) {
                    sleepStatus--; //ensure cannot be greater than 'Wide Awake' aka value 5 in sleepMessage
                }
                cout << "New Sleep Status:";
                sleepMessage(sleepStatus);
                break;

            case 'P':
                happyStatus++;
                if (happiness > 8) {
                    happyStatus--;
                }
                cout << "New Happiness Status:";
                happyCalc(happiness);
                break;

            case 'D':
                cout << "Sleep Status: ";
                sleepMessage(sleepStatus);
                cout << "Food Status: ";
                foodMessage(foodStatus);
                cout << "Happiness Status: ";
                happyCalc(happiness);
                break;
            }
    }

    if (foodStatus == 0) {
        cout << "Game Over, your pet starved to death.";
        gravestone();
    }
    return 0;
}




// FUNCTIONS
    void getInstructions(string petName) {
        cout << "---------------------------------------------" << endl;
        cout << "Press F to feed " << petName << endl;
        cout << "Press N to give a nap to " << petName << endl;
        cout << "Press D to display " << petName << "'s current state" << endl;
        cout << "Press P to play with " << petName << endl;
        cout << "Press Q to quit " << endl;
    }


    void happyCalc(int happyVal) { // just a function that sends something to display, as are all the others. 
        switch (happyVal) {
        case 2:
            cout << "Could not be less happy" << endl;
            break;
        case 3:
            cout << "Profoundly unhappy" << endl;
            break;

        case 4:
            cout << "Unhappy" << endl;
            break;

        case 5:
            cout << "Below Average" << endl;
            break;

        case 6:
            cout << "Average" << endl;
            break;

        case 7:
            cout << "Happy" << endl;

            break;
        case 8:
            cout << "Very Happy" << endl;
            break;

        case 9:
            cout << "Could not be happier" << endl;
            break;
        }
    }

void foodMessage(int foodVal) {

    switch (foodVal) {
    case 1:
        cout << "Starving" << endl;
        break;
    case 2:
        cout << "Rather Hungry" << endl;
        break;
    case 3:
        cout << "Slightly Peckish" << endl;
        break;
    case 4:
        cout << "Well fed" << endl;
        break;
    }

}

void sleepMessage(int sleepVal) {
    switch (sleepVal) {
    case 1:
        cout << "Collapsed" << endl;
        break;
    case 2:
        cout << "Falling Asleep" << endl;
        break;
    case 3:
        cout << "Tired" << endl;
        break;
    case 4:
        cout << "Awake" << endl;
        break;
    case 5:
        cout << "Wide Awake" << endl;
        break;
    }
}

void gravestone() {
    cout << endl << R"(
                 __)(__
           _____/      \\_____
          |  _     ___   _   ||
          | | \     |   | \  ||
          | |  |    |   |  | ||
          | |_/     |   |_/  ||
          | | \     |   |    ||
          | |  \    |   |    ||
          | |   \. _|_. | .  ||
          |                  ||
          |                  ||
          |                  ||
          |                  ||
          |                  ||
          |                  ||)";


}

void timer() {
    while (true) {
        int currentVal = 0;
        using namespace std::chrono_literals;
        auto start = std::chrono::high_resolution_clock::now();
        std::this_thread::sleep_for(3s);
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double, std::milli> elapsed = end - start;
        int randomNum = rand() % 2;
        while (foodStatus > -1 || sleepStatus > 0) {
            if (randomNum == 0) {
                foodStatus--;
                cout << "Food Status: ";
                foodMessage(foodStatus);
                break;
            }
            else {
                cout << "Sleep Status: ";
                sleepMessage(sleepStatus);
                sleepStatus--;
                break;
            }
        }
    }
}

