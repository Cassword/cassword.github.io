Included
- Collection of test files setup for program demonstration
- The python code
- Makefile for dependencies
- SSTI Site for web based testing
- Basic Site for web based testing
- wordlist for usage

HOW TO RUN THE PROGRAM:

1. Open Terminal in folder with makefile (Any Ubuntu distro should do - built for Kali)

2. run command "make install_dependencies" to execute makefile- typing just "make" will show all options. 
  
3. Wait for that to finish installing all python elements and linux tools required

4. This should put you in the venv. Run commands using python within the venv, for an example of all filetypes and their commands see below: 
 
"python CTFSolve.py -f TestFiles/dog.jpg -s HACKSOC\{.*?\} -w rockyou.txt"

"python CTFSolve.py -f TestFiles/find_the_flag.pcapng -s HACKSOC\{.*?\} -w rockyou.txt"

"python CTFSolve.py -f TestFiles/Upload_me.pcapng -s HACKSOC\{.*?\} -w rockyou.txt"

"python CTFSolve.py -f TestFiles/Elsa.txt.zip -s HACKSOC\{.*?\} -w rockyou.txt"

"python CTFSolve.py -f TestFiles/Flag.dd.ad1 -s HACKSOC\{.*?\} -w rockyou.txt"

"python CTFSolve.py -f TestFiles/My_Favourite_Song.wav.zip -s HACKSOC\{.*?\} -w rockyou.txt"

"python CTFSolve.py -f TestFiles/outputOrange.pdf -s HACKSOC\{.*?\} -w rockyou.txt"


IF YOU WANT TO TEST BASIC WEBSITE FLAG FINDING:

1. Within VENV - Run "make serve_basic_site"

2. This should serve a site at "http://0.0.0.0:1234/index.html" 

3. Within VENV - Run test website flag finding with the command:

"python CTFSolve.py -u http://0.0.0.0:1234/index.html -p 400 -s FLAG\{.*?\}" 



IF YOU WANT TO TEST SERVER SIDE TEMPLATE INJECTION:

On account of the fact that SSTI testing requires setting up networking elements, this is not automatically setup. It can be setup with:

1. Within VENV - Run "make install_docker"

2. Assuming success, run "make docker_run" which should setup SSTI

3. WAIT 1 MINUTE 

4. Should now be accessible at http://127.0.0.1:8089/

5. Within VENV - Test SSTI using commands such as: 

"python CTFSolve.py -u http://127.0.0.1:8089 -p 400 -s FLAG\{.*?\}"

(We expect this regex to fail, as there is no regex pattern - but as SSTI is possible you can obtain a shell from which you can run standard linux commands, such as "ls" from which you can "cat flag.txt" to obtain the flag) 



REMOVAL OF VENV AND SHUTTERING OF DOCKER/TMUX:

1. Open Terminal in folder with makefile

2. Run "make clean"






